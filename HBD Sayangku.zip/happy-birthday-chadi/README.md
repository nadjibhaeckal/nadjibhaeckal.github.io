# Happy Birthday, Chadi!

A Pen created on CodePen.io. Original URL: [https://codepen.io/stiliyana/pen/qrLPOV](https://codepen.io/stiliyana/pen/qrLPOV).

Interactive birthday card in a trivia wheel style.