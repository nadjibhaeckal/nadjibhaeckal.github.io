# Happy birthday karaoke

A Pen created on CodePen.io. Original URL: [https://codepen.io/enxaneta/pen/boLBRr](https://codepen.io/enxaneta/pen/boLBRr).

Using:<br><img src="http://d2vlcm61l7u1fs.cloudfront.net/media%2Fccc%2Fcccff140-f376-4b3b-b66d-e91f17ee1563%2FphpWii0Fn.png" alt="Happy Birthday frequencies" />
<br>
The palette used for the canvas: <a href="http://www.colourlovers.com/palette/396247/Melting_Puppies">Melting Puppies</a>