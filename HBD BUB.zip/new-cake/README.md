# new cake

A Pen created on CodePen.io. Original URL: [https://codepen.io/fixcl/pen/bGeWvY](https://codepen.io/fixcl/pen/bGeWvY).

A new birthday, a new cake.

-SVG
-CSS

based on: http://codepen.io/fixcl/pen/nKFDr